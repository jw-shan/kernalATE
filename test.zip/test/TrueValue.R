
### True values specification     
alpha.true  = c(0.1,0.5)
beta.true   = c(0,-0.5)
gamma.true  = c(0.1,-0.5)  
zeta.true   = c(0,-1)
eta.true    = c(-0.5,1)
params.true = list(alpha.true=alpha.true, beta.true=beta.true,
                   gamma.true=gamma.true, zeta.true=zeta.true,
                   eta.true = eta.true)


